# Soul Ascension Landing Page

Optimized React + Tailwind site following the dark black/gold theme.