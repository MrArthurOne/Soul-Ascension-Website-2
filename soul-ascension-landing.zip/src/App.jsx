import React from 'react'
import Navbar from './components/Navbar'
import Hero from './components/Hero'
import Lore from './components/Lore'
import Features from './components/Features'
import ContactBox from './components/ContactBox'
import Footer from './components/Footer'

export default function App() {
  return (
    <div className='min-h-screen text-gray-200 bg-black-850'>
      <Navbar />
      <main className='container'>
        <Hero />
        <Features />
        <Lore />
        <ContactBox />
      </main>
      <Footer />
    </div>
  )
}